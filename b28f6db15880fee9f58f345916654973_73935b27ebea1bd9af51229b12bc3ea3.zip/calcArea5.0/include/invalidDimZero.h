#ifndef INVALIDDIMZERO_H
#define INVALIDDIMZERO_H


class invalidDimZero
{
    public:
        invalidDimZero();
        virtual ~invalidDimZero();

    protected:

    private:
};

#endif // INVALIDDIMZERO_H
