#ifndef CIRCLE_H
#define CIRCLE_H
#include "Shape.h"

/*
Circle class inherits the Shape class
*/
class Circle : public Shape
{
    public:
        Circle(int shapeID, string unitOfMeasure, float radius);// constructor of Circle class
        float getRadius();// function to return the radius of the circle
        void setRadius(float radius); // function to set the radius of the circle with the value passed
		float getArea ();// function to return the area of the circle
		void printShapeDetails(); //function to print the details of the circle
    private:
        float radius; // stores the radius of the circle
};

#endif // CIRCLE_H
