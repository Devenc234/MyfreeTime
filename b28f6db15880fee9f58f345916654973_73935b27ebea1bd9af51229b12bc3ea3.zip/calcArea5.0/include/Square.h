#ifndef SQUARE_H
#define SQUARE_H

#include "Shape.h"

/*
Square class inherits the Shape class
*/
class Square : public Shape
{
    public:
        Square(int tshapeID, string tunitOfMeasure, float tsideLength);// constructor of Square class
        void setSideLength(float);// function to set the side length of the square with the value passed
        float getSideLength();// function to return the side length of the square
        float getArea();// function to return the area of the square
        void printShapeDetails();;//function to print the details of the square

    private:
        float sideLength;// stores the side length of the square

};

#endif // SQUARE_H
