#ifndef ZEROEXCEPTION_H
#define ZEROEXCEPTION_H


class ZeroException
{
    public:
        ZeroException();
        virtual ~ZeroException();

    protected:

    private:
};

#endif // ZEROEXCEPTION_H
