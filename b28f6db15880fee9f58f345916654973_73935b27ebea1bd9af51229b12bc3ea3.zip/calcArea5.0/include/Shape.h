#ifndef SHAPE_H
#define SHAPE_H
#include<string>
#include<iostream>
using namespace std;

/*
Shape class stores the details of the shape
*/
class Shape
{
    public:
        Shape(int tshapeID, string tshapeType, string tunitOfMeasure);// constructor of Shape class
        virtual float getArea()=0;// function to return the area of the shape
        virtual void printShapeDetails();//function to print the details of the shape
    protected:
        int shapeID; // stores the id of the shape
        string shapeType; // stores the type of the shape
        string unitOfMeasure; // stores the unit of measure of shape

};

#endif // SHAPE_H
