#ifndef RECTANGLE_H
#define RECTANGLE_H

#include "Shape.h"

/*
Rectangle class inherits the Shape class
*/
class Rectangle : public Shape
{
    public:
        Rectangle(int tshapeID, string tunitOfMeasure, float tlength, float twidth);// constructor of Rectangle class
        void setLength(float);// function to set the length of the rectangle with the value passed
        void setwidth(float);// function to set the width of the rectangle with the value passed
        float getLength();// function to return the length of the rectangle
        float getwidth();// function to return the width of the rectangle
        float getArea();// function to return the area of the rectangle
        void printShapeDetails();//function to print the details of the rectangle

    private:
        float length;// stores the length of the rectangle
        float width;// stores the width of the rectangle
};

#endif // RECTANGLE_H
