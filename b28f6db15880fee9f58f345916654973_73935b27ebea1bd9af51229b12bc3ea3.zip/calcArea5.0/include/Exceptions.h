#ifndef EXCEPTIONS_H
#define EXCEPTIONS_H


class Exceptions
{
    public:
        Exceptions();
        virtual ~Exceptions();

    protected:

    private:
};

#endif // EXCEPTIONS_H
