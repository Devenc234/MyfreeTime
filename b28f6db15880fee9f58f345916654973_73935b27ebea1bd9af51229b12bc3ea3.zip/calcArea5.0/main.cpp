//ITFP3348 - Nathan Graham - Assessment 5
/*This program builds off of assessment 4 by adding exception
handling to the program. There are two custom exceptions added
to inherit from std::exception to handle invalid dimensions
for shapes such as 0 and negative numbers. */

#include <iostream>
#include "Circle.h"
#include "Rectangle.h"
#include "Square.h"
#include "Shape.h"


using namespace std;

class Exception1 {
public:
    Exception1(){
    }

};

int main()
{
     float input1,input2;

     cout << endl << "---------------Area Calculation------------" << endl;
     //get the radius of the circle
     cout<< "Enter the radius of a circle: ";
     cin>> input1;
      //create object for circle
     Shape* shape=new Circle(1,"cm",input1);
      //print the details of the circle
     shape->printShapeDetails();

     //get the length of the square
     cout<< "\n\nEnter length of one side of the square: ";
     cin >> input1;
      //create object for square
     shape=new Square(2,"cm",input1);
     //print the details of the square
     shape->printShapeDetails();

    //get the length of the rectangle
    cout<< "\n\nEnter the length of a rectangle: ";
    cin >> input1;
    //get the width of the rectangle
    cout<< "Enter the width of a rectangle: ";
    cin >> input2;
    //create object for rectangle
    shape=new Rectangle(3,"cm",input1,input2);
    //print the details of the rectangle
    shape->printShapeDetails();

    cout<<"\n\n***************THANK YOU*******************"<< endl;
    return 0;
}
