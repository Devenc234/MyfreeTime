#include "Circle.h"

/*
    The constructor of circle class to initialize the class variables
*/
Circle:: Circle(int shapeID, string unitOfMeasure, float tradius):Shape(shapeID,"Circle",unitOfMeasure)
{
    radius=tradius;
}
/*
    The getRadius() is used to return the radius of the circle
*/
float Circle::getRadius()
{
	return radius;// return the side radius of the circle
}
/*
     The setRadius() is used to set the radius of the circle
*/
void Circle::setRadius (float r)
{
    radius = r;// set the side radius value
}
/*
    The getArea() is used to return the area of the circle
*/
float Circle::getArea()
{
    return 3.141592653589793 * getRadius() * getRadius();// computes the area of the circle and returns its value
}
/*
    The printShapeDetails() is used to print the details of the circle
*/
void Circle::printShapeDetails()
{
    cout<<"\nCircle Details";
    cout<<"\n*****************";
    Shape::printShapeDetails();
    cout<<"\nCircle Radius: " <<radius<<" "<<unitOfMeasure;
    cout<<"\nCircle Area: "<<getArea() <<" sq"<<unitOfMeasure;
}
