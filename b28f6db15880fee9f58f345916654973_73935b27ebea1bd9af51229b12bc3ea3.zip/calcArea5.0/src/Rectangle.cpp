#include "Rectangle.h"

/*
    The constructor of Rectangle class to initialize the class variables
*/
Rectangle:: Rectangle(int shapeID, string unitOfMeasure, float tlength, float twidth):Shape(shapeID,"Rectangle",unitOfMeasure)
{
    length=tlength;
    width=twidth;
}
/*
    The getLength() is used to return the length of the Rectangle
*/
float Rectangle::getLength()
{
    return length;// return the length of the Rectangle
}
/*
    The getwidth() is used to return the width of the Rectangle
*/
float Rectangle::getwidth()
{
    return width;// return the width of the Rectangle
}
/*
     The setLength() is used to set the length of the Rectangle
*/
void Rectangle::setLength(float tlength)
{
    length=tlength; // set the length of the Rectangle
}
/*
     The setwidth() is used to set the width of the Rectangle
*/
void Rectangle::setwidth(float twidth)
{
    width=twidth; // set the width of the Rectangle
}
/*
    The getArea() is used to return the area of the Rectangle
*/
float Rectangle::getArea()
{
    float area = getLength() * getwidth(); // computes the area of the Rectangle
	return area;// returns its value
}
/*
    The printShapeDetails() is used to print the details of the Rectangle
*/
 void Rectangle::printShapeDetails()
 {
     cout<<"\nRectangle Details";
    cout<<"\n*****************";
    Shape::printShapeDetails();
    cout<<"\nRectangle Length: " <<length<<" "<<unitOfMeasure;
    cout<<"\nRectangle width: " <<width<<" "<<unitOfMeasure;
    cout<<"\nRectangle Area: "<<getArea() <<" sq"<<unitOfMeasure;
}
