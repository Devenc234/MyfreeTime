#include "invalidDimZero.h"

invalidDimZero::invalidDimZero()
{
    //ctor
}

invalidDimZero::~invalidDimZero()
{
    //dtor
}
