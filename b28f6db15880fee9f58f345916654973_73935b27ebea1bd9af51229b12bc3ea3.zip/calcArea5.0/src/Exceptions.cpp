#include "Exceptions.h"

Exceptions::Exceptions()
{
    //ctor
}

Exceptions::~Exceptions()
{
    //dtor
}
