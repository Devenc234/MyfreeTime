#include "Square.h"

/*
    The constructor of Square class to initialize the class variables
*/
Square:: Square(int shapeID, string unitOfMeasure, float tsideLength):Shape(shapeID,"Square",unitOfMeasure)
{
    sideLength=tsideLength;
}
/*
    The getSideLength() is used to return the side length of the square
*/
float Square::getSideLength()
{
    return sideLength; // return the side length of the square
}
/*
     The setSideLength() is used to set the side length of the square
*/
void Square::setSideLength(float tlength)
{
    sideLength=tlength; // set the side length value
}
/*
    The getArea() is used to return the area of the square
*/
float Square::getArea()
{
    return getSideLength()*getSideLength(); // computes the area of the square and returns its value
}
/*
    The printShapeDetails() is used to print the details of the square
*/
 void Square::printShapeDetails()
 {
     cout<<"\nSquare Details";
    cout<<"\n*****************";
    Shape::printShapeDetails();
    cout<<"\nSquare Length: " <<sideLength<<" "<<unitOfMeasure;
    cout<<"\nSquare Area: "<<getArea() <<" sq"<<unitOfMeasure;
}
