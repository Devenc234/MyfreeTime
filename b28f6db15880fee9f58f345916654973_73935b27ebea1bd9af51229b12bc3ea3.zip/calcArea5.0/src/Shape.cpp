#include "Shape.h"
#include "invalidDimZero.h"

/*
    The constructor of Shape class to initialize the class variables
*/
Shape::Shape(int tshapeID, string tshapeType, string tunitOfMeasure)
{
    shapeID=tshapeID;
    shapeType=tshapeType;
    unitOfMeasure=tunitOfMeasure;
}
/*
    The method to print the details of the shape
*/
void Shape::printShapeDetails()
{
    cout<<"\nShape ID: "<<shapeID;
    cout<<"\nShape Type: "<<shapeType;
    cout<<"\nUnits of Measure: "<<unitOfMeasure;
}
