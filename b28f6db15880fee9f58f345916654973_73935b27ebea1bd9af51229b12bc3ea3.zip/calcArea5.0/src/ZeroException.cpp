#include "ZeroException.h"

ZeroException::ZeroException()
{
    //ctor
}

ZeroException::~ZeroException()
{
    //dtor
}
