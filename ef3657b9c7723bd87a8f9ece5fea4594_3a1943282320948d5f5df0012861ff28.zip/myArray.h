#ifndef MYARRAY_H
#define MYARRAY_H
enum myMode { SEQUENTIAL, PRIME, COMPOSITE, FIB };
#define MAX_ARRAY_SIZE	1000

template<typename T>
class MyArray
{
private:
	// MyArray data
public:
	MyArray(const int array_size) {};
	void push_back(T item) {};
	class Iterator
	{
	private:
		// Iterator data and functions
	public:
		Iterator(T* vec) {}
		Iterator(T* vec, int size) {}
		Iterator(T* vec, int size, int pointer) {}
		Iterator(T* vec, int size, int pointer, int mode) {}
		bool operator!=(const Iterator& other) const {};
		Iterator& operator++() {};
		T& operator*() const {};
		T& operator[](int i) const {};
		std::string toString() const {};
		friend std::ostream& operator<< (std::ostream& os, const Iterator& iter) {};
	};
	Iterator begin() {}
	Iterator begin(myMode mode) {}
	Iterator end() {}
	std::string toString() const {};
	friend std::ostream& operator<< (std::ostream& os, const MyArray<T>& myArray) {};
};
#endif // MYARRAY_H
